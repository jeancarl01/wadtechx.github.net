/* =============================================
   app.js — WADTECHX Vanilla JS
   ============================================= */

'use strict';

// ── Data ──────────────────────────────────────

const WHATSAPP = '48203376';
const WA_FULL  = '509' + WHATSAPP;

const SERVICES = [
  { icon: 'wrench',     title: 'Dépannage Informatique',     color: 'from-blue-cyan',
    short: 'Diagnostic et réparation rapide de tous vos équipements informatiques.',
    full:  'Notre équipe d\'experts intervient pour diagnostiquer et résoudre tous types de pannes matérielles et logicielles. Service rapide, garanti et professionnel.' },
  { icon: 'network',    title: 'Câblage Réseaux',            color: 'from-cyan-blue',
    short: 'Installation professionnelle de câblage structuré pour entreprises.',
    full:  'Câblage Ethernet, fibre optique, certification réseau. Nous concevons et installons des infrastructures réseau performantes et évolutives.' },
  { icon: 'harddrive',  title: 'Maintenance Ordinateurs',    color: 'from-blue-indigo',
    short: 'Entretien préventif et curatif pour la longévité de vos systèmes.',
    full:  'Contrats de maintenance personnalisés, nettoyage logiciel, mises à jour, sauvegardes et optimisation des performances de vos ordinateurs.' },
  { icon: 'globe',      title: 'Création de Sites Web',      color: 'from-indigo-blue',
    short: 'Sites vitrines, e-commerce et plateformes sur mesure.',
    full:  'Design moderne, performant et responsive. Nous créons des sites web qui convertissent vos visiteurs en clients, avec les dernières technologies.' },
  { icon: 'smartphone', title: 'Développement d\'Applications', color: 'from-purple-blue',
    short: 'Applications mobiles iOS, Android et web sur mesure.',
    full:  'De l\'idée au déploiement, nous développons des applications natives et hybrides performantes pour iOS, Android et le web.' },
  { icon: 'router',     title: 'Installation Réseaux',       color: 'from-blue-dark',
    short: 'Configuration complète Wi-Fi, LAN, WAN et sécurité.',
    full:  'Installation et configuration de routeurs, switches, points d\'accès Wi-Fi, VPN et systèmes de sécurité réseau professionnels.' },
  { icon: 'headphones', title: 'Support Technique IT',       color: 'from-cyan-blue',
    short: 'Assistance technique disponible 24/7 pour particuliers et entreprises.',
    full:  'Hotline, support à distance et sur site. Notre équipe est disponible pour répondre à toutes vos questions techniques rapidement.' },
];

const SERVICE_COLORS = {
  'from-blue-cyan':  'linear-gradient(135deg, #2563eb, #06b6d4)',
  'from-cyan-blue':  'linear-gradient(135deg, #06b6d4, #2563eb)',
  'from-blue-indigo':'linear-gradient(135deg, #1d4ed8, #6366f1)',
  'from-indigo-blue':'linear-gradient(135deg, #6366f1, #2563eb)',
  'from-purple-blue':'linear-gradient(135deg, #8b5cf6, #2563eb)',
  'from-blue-dark':  'linear-gradient(135deg, #2563eb, #1e3a8a)',
};

const PROJECTS = [
  { id:1,  title:'E-commerce Premium',  cat:'Web',        img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205449399_b4744073.jpg', desc:'Plateforme e-commerce complète avec paiement en ligne et gestion de stock.' },
  { id:2,  title:'Dashboard Analytics', cat:'Web',        img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205451621_e2666f92.jpg', desc:'Tableau de bord SaaS avec visualisations en temps réel.' },
  { id:3,  title:'Site Corporate',      cat:'Web',        img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205478620_dd4b67b7.png', desc:'Site vitrine élégant pour entreprise multinationale.' },
  { id:4,  title:'Plateforme SaaS',     cat:'Web',        img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205457201_da5ef550.png', desc:'Solution SaaS B2B avec authentification multi-tenant.' },
  { id:5,  title:'Data Center Setup',   cat:'Réseaux',    img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205502352_5ca94ca6.png', desc:'Installation complète d\'un centre de données pour PME.' },
  { id:6,  title:'Câblage Bureau',      cat:'Réseaux',    img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205498096_a5e6034c.jpg', desc:'Câblage structuré pour open-space de 100 postes.' },
  { id:7,  title:'Réparation Serveur',  cat:'Maintenance',img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205542825_2446ddff.png', desc:'Maintenance d\'infrastructure serveur critique.' },
  { id:8,  title:'Diagnostic Hardware', cat:'Maintenance',img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205574870_ec8eee4a.png', desc:'Diagnostic et réparation de parc informatique.' },
  { id:9,  title:'App Mobile FinTech',  cat:'Apps',       img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205597886_e2921298.png', desc:'Application mobile bancaire iOS et Android.' },
  { id:10, title:'App Livraison',       cat:'Apps',       img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205601416_eeb2ba4a.png', desc:'Application de livraison avec géolocalisation temps réel.' },
];

const TESTIMONIALS = [
  { name:'Jean-Pierre Louis',   role:'CEO, TechHaiti SA',           rating:5, text:'WADTECHX a transformé notre infrastructure réseau. Service rapide, professionnel et de très haute qualité. Je recommande vivement leur expertise.', avatar:'JL' },
  { name:'Marie Claire Dorvil', role:'Directrice, Boutique Élégance',rating:5, text:'Le site e-commerce qu\'ils ont créé pour nous a doublé nos ventes en ligne. Une équipe à l\'écoute et créative. Bravo!', avatar:'MD' },
  { name:'Patrick Saint-Vil',   role:'IT Manager, GroupeFinance',    rating:5, text:'Maintenance impeccable et support technique disponible 24/7. Nos systèmes n\'ont jamais été aussi performants.', avatar:'PS' },
  { name:'Sophia Pierre',       role:'Fondatrice, StartupHub',       rating:5, text:'Application mobile livrée dans les délais et au-delà de nos attentes. Une vraie agence premium qui maîtrise son art.', avatar:'SP' },
  { name:'David Joseph',        role:'Propriétaire, Hôtel Royal',    rating:5, text:'Câblage réseau parfait pour notre hôtel. Wi-Fi puissant partout. Excellent rapport qualité-prix et équipe respectueuse.', avatar:'DJ' },
  { name:'Nadine Charles',      role:'Directrice Marketing, MediaPlus',rating:5,text:'Une équipe innovante qui comprend les défis modernes. Le dashboard analytics nous fait gagner des heures chaque semaine.', avatar:'NC' },
];

const BLOG_POSTS = [
  { id:1,  cat:'Cybersécurité', title:'Top 10 des menaces de cybersécurité en 2026',              excerpt:'Découvrez les principales cybermenaces qui pèsent sur les entreprises cette année.',              img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205998481_1fba34b3.png', author:'David Joseph',    authorRole:'Expert Cybersécurité',   date:'15 Mai 2026', readTime:8,
    content:`La cybersécurité est devenue un enjeu majeur pour toutes les entreprises.\n\n**1. Ransomware piloté par IA** — Les attaques par rançongiciel utilisent désormais l'IA pour identifier les cibles les plus vulnérables.\n\n**2. Phishing hyper-personnalisé** — Les emails frauduleux trompent même les utilisateurs avertis.\n\n**3. Attaques sur la chaîne d'approvisionnement** — Compromettre un fournisseur pour atteindre des centaines d'entreprises.\n\n**4. Deepfakes audio et vidéo** — Utilisés pour des fraudes au président très convaincantes.\n\n**5. Vulnérabilités IoT** — Les objets connectés mal sécurisés deviennent des portes d'entrée.\n\n**6. Cloud misconfigurations** — Une mauvaise configuration peut exposer des téraoctets de données.\n\n**7. Attaques zero-day** — Exploitation de failles inconnues avant qu'un correctif soit disponible.\n\n**8. Cryptojacking** — Détournement de ressources informatiques pour miner de la crypto.\n\n**9. Menaces internes** — Employés malveillants ou compromis.\n\n**10. Quantum threats** — La cryptographie classique est de plus en plus vulnérable.\n\nChez WADTECHX, nous accompagnons les entreprises dans la mise en place d'une stratégie de cybersécurité complète.` },
  { id:2,  cat:'Réseaux',       title:'Guide complet du câblage réseau pour entreprises',         excerpt:'Tout ce que vous devez savoir pour mettre en place une infrastructure réseau performante.',      img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205502352_5ca94ca6.png', author:'Patrick Saint-Vil',authorRole:'Ingénieur Réseaux',       date:'8 Mai 2026',  readTime:6,
    content:`Un bon câblage réseau est la colonne vertébrale de toute infrastructure IT moderne.\n\n**Choix des câbles** — Cat 6 ou Cat 6A pour 10 Gbps, fibre optique pour les liaisons longues distances.\n\n**Topologie** — En étoile pour la flexibilité, en arbre pour les grands sites.\n\n**Certification** — Tous les câbles doivent être certifiés conformes aux normes TIA/EIA.\n\n**Documentation** — Schéma précis et étiquetage de chaque point pour faciliter la maintenance.\n\n**Bonnes pratiques** — Séparer les câbles électriques, respecter les rayons de courbure, prévoir 20% de capacité supplémentaire.\n\nWADTECHX réalise des installations de câblage structuré certifiées dans tout Haïti.` },
  { id:3,  cat:'Cloud',         title:'Cloud Computing : pourquoi votre PME devrait migrer',      excerpt:'Les avantages concrets du cloud pour les PME et les pièges à éviter lors de la migration.',     img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779206086445_78564fd8.jpg', author:'Sophia Pierre',    authorRole:'Architecte Cloud',        date:'2 Mai 2026',  readTime:7,
    content:`Le cloud computing n'est plus réservé aux grandes entreprises.\n\n**Réduction des coûts** — Plus besoin d'investir dans des serveurs coûteux. Vous payez ce que vous consommez.\n\n**Flexibilité** — Augmentez ou réduisez vos ressources en quelques clics.\n\n**Sécurité** — Les fournisseurs cloud investissent massivement dans la sécurité.\n\n**Mobilité** — Accédez à vos données depuis n'importe où.\n\n**Continuité d'activité** — Sauvegardes automatiques et reprise d'activité simplifiée.\n\n**Précautions** — Choisissez un fournisseur réputé, chiffrez vos données sensibles, prévoyez une stratégie de sortie.` },
  { id:4,  cat:'Tendances IT',  title:'Comment l\'IA révolutionne le développement web',          excerpt:'De GitHub Copilot à ChatGPT, découvrez comment l\'IA transforme le métier de développeur.',     img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779206104198_dba39789.jpg', author:'Nadine Charles',   authorRole:'Lead Developer',          date:'28 Avr 2026', readTime:9,
    content:`L'IA n'est plus une simple tendance, c'est une révolution qui transforme le développement web.\n\n**Génération de code** — Les assistants IA produisent du code de qualité en quelques secondes.\n\n**Tests automatisés** — L'IA génère des tests pertinents qui couvrent les cas limites.\n\n**Design automatique** — Des outils comme Figma AI créent des interfaces complètes à partir d'un prompt.\n\n**Optimisation** — Détection automatique des goulots d'étranglement et suggestions d'amélioration.\n\n**Personnalisation** — Adaptation du contenu en temps réel selon le comportement utilisateur.\n\nL'IA ne remplace pas les développeurs mais les rend infiniment plus productifs.` },
  { id:5,  cat:'Tutoriels',     title:'Tutoriel : sécuriser votre Wi-Fi d\'entreprise en 10 étapes',excerpt:'Un guide pratique étape par étape pour transformer votre réseau Wi-Fi en forteresse.',       img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779206129542_31e4835b.png', author:'Marie Claire Dorvil',authorRole:'Consultante Sécurité',  date:'20 Avr 2026', readTime:5,
    content:`Un Wi-Fi mal sécurisé est une porte d'entrée privilégiée pour les pirates.\n\n**1.** Activez WPA3 (ou WPA2 minimum).\n**2.** Utilisez un mot de passe complexe (min 16 caractères).\n**3.** Changez le SSID par défaut.\n**4.** Désactivez WPS.\n**5.** Activez le filtrage MAC pour les appareils critiques.\n**6.** Créez un réseau invité séparé.\n**7.** Mettez à jour le firmware du routeur régulièrement.\n**8.** Désactivez l'administration à distance.\n**9.** Utilisez un VPN pour les accès externes.\n**10.** Surveillez les connexions actives.\n\nSuivez ces étapes et votre Wi-Fi sera nettement plus sûr.` },
  { id:6,  cat:'Tutoriels',     title:'15 astuces pour booster les performances de votre ordinateur',excerpt:'Votre PC rame ? Découvrez nos astuces de professionnels pour lui redonner une seconde jeunesse.',img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205542825_2446ddff.png', author:'Jean-Pierre Louis', authorRole:'Technicien Senior',       date:'14 Avr 2026', readTime:6,
    content:`Pas besoin d'acheter un nouveau PC ! Voici 15 astuces pour le rendre plus rapide.\n\n**1.** Nettoyez le disque dur.\n**2.** Désinstallez les programmes inutilisés.\n**3.** Désactivez les programmes au démarrage.\n**4.** Mettez à jour le système d'exploitation.\n**5.** Installez un SSD à la place du HDD.\n**6.** Augmentez la RAM si possible.\n**7.** Vérifiez la présence de malwares.\n**8.** Défragmentez (HDD uniquement).\n**9.** Nettoyez physiquement l'intérieur (poussière).\n**10.** Renouvelez la pâte thermique.\n**11.** Désactivez les effets visuels superflus.\n**12.** Utilisez un navigateur léger.\n**13.** Limitez les onglets ouverts.\n**14.** Mettez à jour les pilotes.\n**15.** Réinstallez Windows en dernier recours.` },
  { id:7,  cat:'Tendances IT',  title:'Les 7 tendances du développement mobile en 2026',           excerpt:'Cross-platform, IA embarquée, AR/VR... découvrez ce qui façonne l\'avenir des apps mobiles.',  img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205597886_e2921298.png', author:'Sophia Pierre',    authorRole:'Mobile Architect',        date:'6 Avr 2026',  readTime:7,
    content:`Le monde du développement mobile évolue à une vitesse fulgurante.\n\n**1. Flutter et React Native** dominent toujours le cross-platform.\n**2. IA embarquée** — Modèles d'IA directement dans l'app.\n**3. Super-apps** — Une seule app pour tout faire.\n**4. Réalité augmentée** — Démocratisation grâce à ARKit et ARCore.\n**5. 5G** — Nouvelles expériences possibles grâce à la latence ultra-faible.\n**6. Foldables** — Adaptation aux écrans pliables.\n**7. Privacy-first** — Conformité RGPD et respect de la vie privée.` },
  { id:8,  cat:'Réseaux',       title:'Wi-Fi Mesh vs Wi-Fi traditionnel : que choisir ?',          excerpt:'Comparaison détaillée pour vous aider à faire le meilleur choix selon vos besoins.',            img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779205498096_a5e6034c.jpg', author:'Patrick Saint-Vil',authorRole:'Ingénieur Réseaux',       date:'28 Mar 2026', readTime:5,
    content:`Wi-Fi Mesh ou Wi-Fi traditionnel ? Le choix dépend de plusieurs critères.\n\n**Wi-Fi traditionnel** — Idéal pour les petits espaces. Coût d'entrée faible. Configuration simple.\n\n**Wi-Fi Mesh** — Parfait pour les grandes surfaces. Itinérance transparente entre les nœuds. Plus cher mais bien plus performant pour les grandes maisons et bureaux.\n\n**Recommandation** — Pour un appartement ou un petit bureau, un bon routeur suffit. Pour une maison à étages ou un bureau de plus de 200m², le Mesh est imbattable.` },
  { id:9,  cat:'Cybersécurité', title:'La stratégie 3-2-1 : sauvegarder vos données comme un pro', excerpt:'La règle d\'or des sauvegardes expliquée simplement, avec des conseils concrets.',              img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779206050984_e7983abb.png', author:'David Joseph',    authorRole:'Expert Cybersécurité',   date:'20 Mar 2026', readTime:6,
    content:`Perdre ses données est une catastrophe évitable. La stratégie 3-2-1 est la référence.\n\n**3** copies de vos données.\n**2** supports différents (disque dur + cloud par exemple).\n**1** copie hors site.\n\n**Mise en pratique** — Configurez des sauvegardes automatiques quotidiennes, testez régulièrement la restauration, chiffrez les copies sensibles.\n\nAvec cette stratégie, même une catastrophe majeure ne vous empêchera pas de récupérer vos données.` },
  { id:10, cat:'Tutoriels',     title:'DevOps pour débutants : par où commencer ?',                excerpt:'Le DevOps démystifié : concepts clés, outils essentiels et roadmap pour débuter.',              img:'https://d64gsuwffb70l.cloudfront.net/6a0c84989807e531d30ee30d_1779206134887_a9711fae.png', author:'Nadine Charles',   authorRole:'DevOps Engineer',         date:'12 Mar 2026', readTime:8,
    content:`Le DevOps n'est pas qu'un buzzword, c'est une révolution dans la livraison de logiciels.\n\n**Concepts clés** — Intégration continue, déploiement continu, infrastructure as code, monitoring.\n\n**Outils incontournables** — Git, Docker, Kubernetes, Jenkins/GitHub Actions, Terraform, Prometheus.\n\n**Roadmap** — Maîtrisez Linux, apprenez le scripting (Bash, Python), comprenez les conteneurs, automatisez vos déploiements.\n\nLe DevOps demande du temps mais transforme radicalement la productivité d'une équipe.` },
];

const CAT_COLORS = {
  'Cybersécurité': 'linear-gradient(135deg,#ef4444,#f97316)',
  'Réseaux':       'linear-gradient(135deg,#2563eb,#06b6d4)',
  'Cloud':         'linear-gradient(135deg,#8b5cf6,#2563eb)',
  'Tendances IT':  'linear-gradient(135deg,#22d3ee,#2563eb)',
  'Tutoriels':     'linear-gradient(135deg,#10b981,#06b6d4)',
};

// ── SVG Icons ─────────────────────────────────

const ICONS = {
  zap:         `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
  menu:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
  x:           `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  sun:         `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`,
  moon:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`,
  arrowRight:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
  sparkles:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z"/><path d="M5 19l.75 2.25L8 22l-2.25.75L5 25l-.75-2.25L2 22l2.25-.75z" opacity=".5"/></svg>`,
  cpu:         `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/></svg>`,
  wifi:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>`,
  wrench:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`,
  network:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="16" y="16" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="9" y="2" width="6" height="6" rx="1"/><path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"/><line x1="12" y1="12" x2="12" y2="8"/></svg>`,
  harddrive:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="12" x2="2" y2="12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" y1="16" x2="6.01" y2="16"/><line x1="10" y1="16" x2="10.01" y2="16"/></svg>`,
  globe:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`,
  smartphone:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>`,
  router:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="14" width="20" height="8" rx="2"/><path d="M6.01 18H6"/><path d="M10.01 18H10"/><path d="M15 10h.01"/><path d="M17.84 7.17a4 4 0 0 0-5.66 0"/><path d="M20.66 4.34a8 8 0 0 0-11.31 0"/></svg>`,
  headphones:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>`,
  externalLink:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
  chevLeft:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>`,
  chevRight:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>`,
  quote:       `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1zm12 0c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"/></svg>`,
  star:        `<svg viewBox="0 0 24 24" fill="#facc15" stroke="#facc15" stroke-width="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  send:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`,
  mail:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>`,
  phone:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.64 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.1 6.1l.97-.97a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
  mapPin:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>`,
  msgCircle:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`,
  facebook:    `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>`,
  instagram:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>`,
  linkedin:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>`,
  twitter:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>`,
  award:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>`,
  lightbulb:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="9" y1="18" x2="15" y2="18"/><line x1="10" y1="22" x2="14" y2="22"/><path d="M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14"/></svg>`,
  users:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
  shield:      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>`,
  briefcase:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>`,
  clock:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  check:       `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  book:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`,
  calendar:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
  checkCircle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  arrowLeft:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>`,
};

function icon(name, cls = '') {
  const svg = ICONS[name] || '';
  if (!cls) return svg;
  return svg.replace('<svg', `<svg class="${cls}"`);
}

// ── State ──────────────────────────────────────

let darkMode = true;
let mobileNavOpen = false;
let selectedService = null;
let portfolioFilter = 'Tous';
let lightboxProject = null;
let testimonialPage = 0;
let testimonialTimer = null;
let blogPageOpen = false;
let blogFilter = 'Tous';
let selectedPostId = null;
let waOpen = false;
let waShowPing = true;
let waHideTimer = null;

// ── Helpers ────────────────────────────────────

function scrollToSection(id) {
  const el = document.querySelector(id);
  if (el) el.scrollIntoView({ behavior: 'smooth' });
  closeMobileNav();
}

function formatContent(text) {
  return text
    .split('\n')
    .map(line => {
      line = line.trim();
      if (!line) return '';
      // Bold headings **text**
      line = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      return `<p>${line}</p>`;
    })
    .filter(Boolean)
    .join('');
}

// ── Header ──────────────────────────────────────

function initHeader() {
  const header = document.getElementById('header');
  const themeBtn = document.getElementById('theme-btn');
  const themeIcon = document.getElementById('theme-icon');
  const hamburger = document.getElementById('hamburger');
  const hamburgerIcon = document.getElementById('hamburger-icon');

  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 30);
  });

  themeBtn.addEventListener('click', () => {
    darkMode = !darkMode;
    themeIcon.innerHTML = darkMode ? ICONS.sun : ICONS.moon;
    // Site is always dark-themed, toggle is visual only in this version
  });

  hamburger.addEventListener('click', () => {
    mobileNavOpen = !mobileNavOpen;
    hamburgerIcon.innerHTML = mobileNavOpen ? ICONS.x : ICONS.menu;
    document.getElementById('mobile-nav').classList.toggle('open', mobileNavOpen);
  });
}

function closeMobileNav() {
  mobileNavOpen = false;
  const hamburgerIcon = document.getElementById('hamburger-icon');
  if (hamburgerIcon) hamburgerIcon.innerHTML = ICONS.menu;
  const nav = document.getElementById('mobile-nav');
  if (nav) nav.classList.remove('open');
}

// ── Services ────────────────────────────────────

function renderServices() {
  const grid = document.getElementById('services-grid');
  if (!grid) return;

  let html = SERVICES.map((s, i) => {
    const grad = SERVICE_COLORS[s.color] || SERVICE_COLORS['from-blue-cyan'];
    return `
    <div class="service-card reveal reveal-delay-${(i % 3) + 1}" onclick="openServiceModal(${i})">
      <div class="service-card-glow" style="background:${grad}"></div>
      <div class="service-icon" style="background:${grad}">
        ${icon(s.icon)}
      </div>
      <h3 class="service-title">${s.title}</h3>
      <p class="service-desc">${s.short}</p>
      <span class="service-link">En savoir plus ${icon('arrowRight')}</span>
    </div>`;
  }).join('');

  html += `
  <div class="service-cta-card reveal reveal-delay-3 bg-grid-white">
    <div>
      <h3 class="service-cta-title">Besoin d'un projet sur mesure ?</h3>
      <p class="service-cta-desc">Discutons de votre vision technologique.</p>
    </div>
    <button class="service-cta-btn" onclick="scrollToSection('#contact')">
      Démarrer maintenant ${icon('arrowRight')}
    </button>
  </div>`;

  grid.innerHTML = html;
}

window.openServiceModal = function(i) {
  selectedService = i;
  const s = SERVICES[i];
  const grad = SERVICE_COLORS[s.color] || SERVICE_COLORS['from-blue-cyan'];
  const modal = document.getElementById('service-modal');
  document.getElementById('modal-icon').style.background = grad;
  document.getElementById('modal-icon').innerHTML = icon(s.icon);
  document.getElementById('modal-title').textContent = s.title;
  document.getElementById('modal-desc').textContent  = s.full;
  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
};

window.closeServiceModal = function() {
  document.getElementById('service-modal').style.display = 'none';
  document.body.style.overflow = '';
};

// ── Portfolio ────────────────────────────────────

function renderPortfolio() {
  const grid = document.getElementById('portfolio-grid');
  if (!grid) return;
  const filtered = portfolioFilter === 'Tous'
    ? PROJECTS
    : PROJECTS.filter(p => p.cat === portfolioFilter);

  grid.innerHTML = filtered.map(p => `
    <div class="portfolio-item reveal" onclick="openLightbox(${p.id})">
      <img src="${p.img}" alt="${p.title}" loading="lazy">
      <div class="portfolio-overlay"></div>
      <div class="portfolio-info">
        <span class="portfolio-cat">${p.cat}</span>
        <h3 class="portfolio-name">${p.title}</h3>
        <div class="portfolio-view">Voir le projet ${icon('externalLink')}</div>
      </div>
    </div>`).join('');

  initReveal();
}

window.openLightbox = function(id) {
  const p = PROJECTS.find(x => x.id === id);
  if (!p) return;
  lightboxProject = p;
  const lb = document.getElementById('lightbox');
  document.getElementById('lb-img').src   = p.img;
  document.getElementById('lb-img').alt   = p.title;
  document.getElementById('lb-cat').textContent   = p.cat;
  document.getElementById('lb-title').textContent = p.title;
  document.getElementById('lb-desc').textContent  = p.desc;
  lb.style.display = 'flex';
  document.body.style.overflow = 'hidden';
};

window.closeLightbox = function() {
  document.getElementById('lightbox').style.display = 'none';
  document.body.style.overflow = '';
};

function initPortfolioFilters() {
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      portfolioFilter = btn.dataset.filter;
      renderPortfolio();
    });
  });
}

// ── Stats counter ────────────────────────────────

function animateCounter(el, end, suffix) {
  let start = 0;
  const duration = 2000;
  const step = end / (duration / 16);
  const interval = setInterval(() => {
    start += step;
    if (start >= end) {
      el.textContent = end + suffix;
      clearInterval(interval);
    } else {
      el.textContent = Math.floor(start) + suffix;
    }
  }, 16);
}

function initStats() {
  const section = document.getElementById('stats');
  if (!section) return;
  let triggered = false;
  const obs = new IntersectionObserver(([e]) => {
    if (e.isIntersecting && !triggered) {
      triggered = true;
      document.querySelectorAll('[data-counter]').forEach(el => {
        animateCounter(el, parseInt(el.dataset.end), el.dataset.suffix);
      });
    }
  }, { threshold: 0.3 });
  obs.observe(section);
}

// ── Testimonials ─────────────────────────────────

const PER_PAGE = 3;
const PAGES = Math.ceil(TESTIMONIALS.length / PER_PAGE);

function renderTestimonials() {
  const grid = document.getElementById('testimonials-grid');
  const dots = document.getElementById('testimonials-dots');
  if (!grid) return;

  const visible = TESTIMONIALS.slice(testimonialPage * PER_PAGE, testimonialPage * PER_PAGE + PER_PAGE);
  grid.style.opacity = '0';
  setTimeout(() => {
    grid.innerHTML = visible.map((t, i) => `
      <div class="testimonial-card" style="animation-delay:${i*0.1}s">
        <div class="quote-icon">${icon('quote')}</div>
        <div class="stars">${'<span class="star">'+icon('star')+'</span>'.repeat(t.rating)}</div>
        <p class="testimonial-text">"${t.text}"</p>
        <div class="testimonial-author">
          <div class="author-avatar">${t.avatar}</div>
          <div>
            <div class="author-name">${t.name}</div>
            <div class="author-role">${t.role}</div>
          </div>
        </div>
      </div>`).join('');
    grid.style.opacity = '1';
  }, 150);

  if (dots) {
    dots.innerHTML = Array.from({ length: PAGES }, (_, i) =>
      `<button class="dot-btn ${i === testimonialPage ? 'active' : ''}" onclick="goToTestimonialPage(${i})"></button>`
    ).join('');
  }
}

window.goToTestimonialPage = function(page) {
  testimonialPage = page;
  renderTestimonials();
  resetTestimonialTimer();
};

window.prevTestimonials = function() {
  testimonialPage = (testimonialPage - 1 + PAGES) % PAGES;
  renderTestimonials();
  resetTestimonialTimer();
};

window.nextTestimonials = function() {
  testimonialPage = (testimonialPage + 1) % PAGES;
  renderTestimonials();
  resetTestimonialTimer();
};

function resetTestimonialTimer() {
  clearInterval(testimonialTimer);
  testimonialTimer = setInterval(() => {
    testimonialPage = (testimonialPage + 1) % PAGES;
    renderTestimonials();
  }, 6000);
}

// ── Blog ──────────────────────────────────────────

function getBlogCatColor(cat) {
  return CAT_COLORS[cat] || 'linear-gradient(135deg,#2563eb,#06b6d4)';
}

function renderBlogSection() {
  const grid = document.getElementById('blog-grid');
  if (!grid) return;
  const featured = BLOG_POSTS.slice(0, 3);
  grid.innerHTML = featured.map(p => renderBlogCard(p)).join('');
  initReveal();
}

function renderBlogCard(p) {
  return `
  <article class="blog-card reveal" onclick="openBlogPost(${p.id})">
    <div class="blog-card-img">
      <img src="${p.img}" alt="${p.title}" loading="lazy">
      <div class="blog-card-img-overlay"></div>
      <span class="blog-card-cat" style="background:${getBlogCatColor(p.cat)}">${p.cat}</span>
      <div class="blog-card-read">${icon('clock')} ${p.readTime} min</div>
    </div>
    <div class="blog-card-body">
      <div class="blog-card-meta">
        ${icon('calendar')} ${p.date} <span>•</span> ${p.author}
      </div>
      <h3 class="blog-card-title">${p.title}</h3>
      <p class="blog-card-excerpt">${p.excerpt}</p>
      <div class="blog-read-link">Lire l'article ${icon('arrowRight')}</div>
    </div>
  </article>`;
}

window.openBlogPage = function() {
  blogPageOpen = true;
  document.body.style.overflow = 'hidden';
  const overlay = document.getElementById('blog-page');
  overlay.style.display = 'block';
  renderBlogPageGrid();
};

window.closeBlogPage = function() {
  blogPageOpen = false;
  document.body.style.overflow = '';
  document.getElementById('blog-page').style.display = 'none';
};

function renderBlogPageGrid() {
  const grid = document.getElementById('blog-page-grid');
  if (!grid) return;
  const posts = blogFilter === 'Tous'
    ? BLOG_POSTS
    : BLOG_POSTS.filter(p => p.cat === blogFilter);
  grid.innerHTML = posts.map(p => renderBlogCard(p)).join('');
}

function initBlogPageFilters() {
  document.querySelectorAll('.blog-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.blog-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      blogFilter = btn.dataset.filter;
      renderBlogPageGrid();
    });
  });
}

window.openBlogPost = function(id) {
  selectedPostId = id;
  const post = BLOG_POSTS.find(p => p.id === id);
  if (!post) return;

  const overlay = document.getElementById('blog-detail');
  overlay.style.display = 'block';
  document.body.style.overflow = 'hidden';

  document.getElementById('bd-img').src          = post.img;
  document.getElementById('bd-img').alt          = post.title;
  document.getElementById('bd-cat').textContent   = post.cat;
  document.getElementById('bd-cat').style.background = getBlogCatColor(post.cat);
  document.getElementById('bd-title').textContent = post.title;
  document.getElementById('bd-author-av').textContent = post.author.split(' ').map(w => w[0]).slice(0,2).join('');
  document.getElementById('bd-author-name').textContent = post.author;
  document.getElementById('bd-author-role').textContent = post.authorRole;
  document.getElementById('bd-date').textContent  = post.date;
  document.getElementById('bd-read').textContent  = post.readTime + ' min de lecture';
  document.getElementById('bd-body').innerHTML    = formatContent(post.content);
  overlay.scrollTop = 0;
};

window.closeBlogDetail = function() {
  selectedPostId = null;
  document.getElementById('blog-detail').style.display = 'none';
  if (!blogPageOpen) document.body.style.overflow = '';
};

// ── Contact Form ──────────────────────────────────

function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name    = document.getElementById('f-name').value.trim();
    const email   = document.getElementById('f-email').value.trim();
    const phone   = document.getElementById('f-phone').value.trim();
    const message = document.getElementById('f-message').value.trim();
    const errEl   = document.getElementById('f-error');
    const sucEl   = document.getElementById('f-success');
    const btnEl   = document.getElementById('f-submit');

    errEl.style.display = 'none';
    sucEl.style.display = 'none';

    if (!name || !email || !message) {
      errEl.textContent = 'Veuillez remplir tous les champs obligatoires.';
      errEl.style.display = 'block';
      return;
    }

    btnEl.disabled = true;
    btnEl.innerHTML = '<span class="spinner"></span> Envoi...';

    try {
      await fetch('https://famous.ai/api/crm/6a0c84989807e531d30ee30d/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name, source:'contact-form', tags:['wadtechx','contact','lead'] }),
      }).catch(() => {});

      const text = encodeURIComponent(
        `Bonjour WADTECHX!\n\nJe suis ${name}\nEmail: ${email}\nTéléphone: ${phone || 'Non fourni'}\n\nMessage:\n${message}`
      );
      window.open(`https://wa.me/${WA_FULL}?text=${text}`, '_blank');

      sucEl.style.display = 'flex';
      form.reset();
      setTimeout(() => { sucEl.style.display = 'none'; }, 6000);
    } catch {
      errEl.textContent = 'Une erreur est survenue. Veuillez réessayer.';
      errEl.style.display = 'block';
    } finally {
      btnEl.disabled = false;
      btnEl.innerHTML = `Envoyer le message ${icon('send')}`;
    }
  });
}

// ── Newsletter ────────────────────────────────────

function initNewsletter() {
  const form = document.getElementById('newsletter-form');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const emailEl = document.getElementById('nl-email');
    const email = emailEl.value.trim();
    if (!email) return;
    try {
      await fetch('https://famous.ai/api/crm/6a0c84989807e531d30ee30d/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source:'footer-signup', tags:['wadtechx','newsletter','footer'] }),
      }).catch(() => {});
      document.getElementById('nl-success').style.display = 'block';
      emailEl.value = '';
      setTimeout(() => { document.getElementById('nl-success').style.display = 'none'; }, 4000);
    } catch {}
  });
}

// ── WhatsApp Float ────────────────────────────────

function initWhatsApp() {
  const floatBtn = document.getElementById('wa-float-btn');
  const panel    = document.getElementById('wa-panel');
  const closeBtn = document.getElementById('wa-close');
  const sendBtn  = document.getElementById('wa-send');
  const input    = document.getElementById('wa-input');

  // Auto-hide ping after 10s
  waHideTimer = setTimeout(() => {
    const ping  = document.getElementById('wa-ping');
    const badge = document.getElementById('wa-badge');
    if (ping)  ping.style.display = 'none';
    if (badge) badge.style.display = 'none';
    waShowPing = false;
  }, 10000);

  floatBtn.addEventListener('click', () => {
    waOpen = !waOpen;
    panel.style.display = waOpen ? 'block' : 'none';
    floatBtn.innerHTML = waOpen ? icon('x') : `
      ${waShowPing ? '<span class="wa-ping"></span><span class="wa-badge" id="wa-badge">1</span>' : ''}
      ${icon('msgCircle')}`;
    if (waOpen) {
      const ping  = document.getElementById('wa-ping');
      const badge = document.getElementById('wa-badge');
      if (ping)  ping.style.display = 'none';
      if (badge) badge.style.display = 'none';
      clearTimeout(waHideTimer);
      waShowPing = false;
    }
  });

  closeBtn.addEventListener('click', () => {
    waOpen = false;
    panel.style.display = 'none';
    floatBtn.innerHTML = icon('msgCircle');
  });

  sendBtn.addEventListener('click', () => sendWAMessage());
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendWAMessage(); });

  document.querySelectorAll('.wa-quick-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const text = encodeURIComponent(btn.textContent.trim());
      window.open(`https://wa.me/${WA_FULL}?text=${text}`, '_blank');
      waOpen = false;
      panel.style.display = 'none';
      floatBtn.innerHTML = icon('msgCircle');
    });
  });
}

function sendWAMessage() {
  const input = document.getElementById('wa-input');
  const msg = input.value.trim() || 'Bonjour WADTECHX, je souhaite plus d\'informations.';
  window.open(`https://wa.me/${WA_FULL}?text=${encodeURIComponent(msg)}`, '_blank');
  input.value = '';
  waOpen = false;
  document.getElementById('wa-panel').style.display = 'none';
  document.getElementById('wa-float-btn').innerHTML = icon('msgCircle');
}

// ── Scroll Reveal ─────────────────────────────────

function initReveal() {
  const els = document.querySelectorAll('.reveal:not(.visible)');
  if (!els.length) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  els.forEach(el => obs.observe(el));
}

// ── Close overlays on Escape ──────────────────────

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (selectedPostId) { closeBlogDetail(); return; }
    if (blogPageOpen)   { closeBlogPage();   return; }
    if (lightboxProject){ closeLightbox();   return; }
    if (selectedService !== null) { closeServiceModal(); return; }
    if (waOpen) {
      waOpen = false;
      document.getElementById('wa-panel').style.display = 'none';
      document.getElementById('wa-float-btn').innerHTML = icon('msgCircle');
    }
  }
});

// ── Init ──────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  renderServices();
  initPortfolioFilters();
  renderPortfolio();
  initStats();
  renderTestimonials();
  resetTestimonialTimer();
  renderBlogSection();
  initBlogPageFilters();
  initContactForm();
  initNewsletter();
  initWhatsApp();
  initReveal();

  // Observe new elements added dynamically
  const mo = new MutationObserver(() => initReveal());
  mo.observe(document.body, { childList: true, subtree: true });
});
